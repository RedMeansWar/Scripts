fx_version 'cerulean'
game 'gta5'

author 'RedMeansWar'
description 'Grab Script written in C#'
version '1.0.0'

file 'Red.Common.Client.net.dll'

client_script 'Red.Grab.Client.net.dll'
server_script 'Red.Grab.Server.net.dll'