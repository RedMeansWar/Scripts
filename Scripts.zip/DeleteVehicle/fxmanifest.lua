fx_version 'cerulean'
game 'gta5'

author 'RedMeansWar'
description 'Delete Vehicle Script written in C#'
version '1.0.0'

file 'Red.Common.Client.net.dll'

client_script 'Red.DeleteVehicle.Client.net.dll'
server_script 'Red.DeleteVehicle.Server.net.dll'