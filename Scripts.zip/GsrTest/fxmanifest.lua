fx_version 'cerulean'
game 'gta5'

author 'RedMeansWar'
description 'Delete Vehicle Script written in C#'
version '1.0.0'

file 'Red.Common.Client.net.dll'

client_script 'Red.GsrTest.Client.net.dll'
server_script 'Red.GsrTest.Server.net.dll'