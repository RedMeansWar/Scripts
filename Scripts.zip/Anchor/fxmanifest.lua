fx_version 'cerulean'
game 'gta5'

author 'RedMeansWar'
description 'Boat Anchor script written in C#'
version '1.0.0'

file 'Red.Common.Client.net.dll'

client_script 'Red.Anchor.Client.net.dll'