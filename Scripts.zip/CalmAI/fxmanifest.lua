fx_version 'cerulean'
game 'gta5'

author 'RedMeansWar'
description 'CalmAI Script written in C#'
version '1.0.0'

client_script 'Red.CalmAI.Client.net.dll'