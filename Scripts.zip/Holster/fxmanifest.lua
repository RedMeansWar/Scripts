fx_version 'cerulean'
game 'gta5'

author 'RedMeansWar'
description 'Holster Script written in C#'
version '1.0.0'

file 'Red.Common.Client.net.dll'

client_script 'Red.Holster.Client.net.dll'